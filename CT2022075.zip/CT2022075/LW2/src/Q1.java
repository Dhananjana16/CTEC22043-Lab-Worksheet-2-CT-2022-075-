public class Q1 {
    public static void main(String[] args) {

        int A = 2;
        int B = 3;
        int C = 4;
        int X = 5;
        int Y = 2;
        double r = 7;


        double resultA = Math.sqrt((B * B) + (4 * A * C));
        System.out.println("sqrt(B^2 + 4AC) = " + resultA);


        double resultB = Math.sqrt(X + (4 * Math.pow(Y, 3)));
        System.out.println("sqrt(X + 4Y^3) = " + resultB);


        double resultC = Math.cbrt(X * Y);
        System.out.println("cbrt(X * Y) = " + resultC);

       
        double areaCircle = Math.PI * Math.pow(r, 2);
        System.out.println("Area of circle = " + areaCircle);
    }
}





