import java.util.Scanner;

public class Q9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter investment: ");
        double P = scanner.nextDouble();
        System.out.print("Enter interest: ");
        double R = scanner.nextDouble();
        System.out.print("Enter years: ");
        int N = scanner.nextInt();

        double amount = P * Math.pow(1 + (R / 100), N);
        System.out.println("Amount after " + N + " years: " + amount);
    }
}

