import java.util.Scanner;
import java.time.Year;

public class Q6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int currentYear = Year.now().getValue();

        System.out.print("Enter birth year: ");
        int birthYear = scanner.nextInt();

        int age = currentYear - birthYear;
        System.out.println("You will be " + age + " this year.");
    }
}

